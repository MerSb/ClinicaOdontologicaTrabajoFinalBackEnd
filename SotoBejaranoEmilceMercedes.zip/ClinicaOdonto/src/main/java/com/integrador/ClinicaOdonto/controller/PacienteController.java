package com.integrador.ClinicaOdonto.controller;

import com.integrador.ClinicaOdonto.DTO.PacienteDTO;
import com.integrador.ClinicaOdonto.entity.Paciente;
import com.integrador.ClinicaOdonto.exception.ExcepcionesGlobales;
import com.integrador.ClinicaOdonto.service.PacienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/pacientes")
public class PacienteController {
    @Autowired
    private PacienteService service;
    @PostMapping
    public ResponseEntity<PacienteDTO> crear(@RequestBody Paciente paciente){
        ResponseEntity response;

        PacienteDTO pacienteDto = null;
        try {
            pacienteDto = service.crear(paciente);
            response = ResponseEntity.ok(pacienteDto);
        } catch (ExcepcionesGlobales e) {
            response = ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());

        }


        return response;
    }
    @GetMapping("/{id}")
    public ResponseEntity<PacienteDTO> buscarPorId(@PathVariable Integer id){
        ResponseEntity response;
        try{
            PacienteDTO pacienteDTO = service.buscarPorId(id);
            response = ResponseEntity.ok("Se encontro un paciente correctamente por su id");
        }catch (ExcepcionesGlobales e){
            response = ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
        return response;
    }
    @GetMapping
    public  ResponseEntity<Iterable <PacienteDTO>> Listar(){
        ResponseEntity response;
        try{
            List<PacienteDTO> pacienteDTOList = service.listarTodo();
            response = ResponseEntity.ok(pacienteDTOList);
        }catch (ExcepcionesGlobales e){
            response = ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
        return response;
    }
    @PutMapping()
    public ResponseEntity<PacienteDTO> modificarPaciente(@RequestBody Paciente paciente){
        ResponseEntity response;
        try{
            PacienteDTO PacienteDTO = service.actualizar(paciente);
            response = ResponseEntity.ok(PacienteDTO);
        }catch (ExcepcionesGlobales e){
            response = ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
        return response;

    }

    @DeleteMapping("/{id}")
    public ResponseEntity<PacienteDTO> eliminarPaciente(@PathVariable Integer id) {
        ResponseEntity response;
        try {
            service.borrarPorId(id);
            response = ResponseEntity.ok("Se borro con exito al paciente");
        } catch (ExcepcionesGlobales e) {
            response = ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
        return response;
    }

}
