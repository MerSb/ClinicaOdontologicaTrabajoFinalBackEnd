package com.integrador.ClinicaOdonto.controller;

import com.integrador.ClinicaOdonto.DTO.OdontologoDTO;
import com.integrador.ClinicaOdonto.entity.Odontologo;
import com.integrador.ClinicaOdonto.exception.ExcepcionesGlobales;
import com.integrador.ClinicaOdonto.service.OdontologoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/odontologos")
public class OdontologoController {

    @Autowired
    private OdontologoService service;

    @PostMapping
    public ResponseEntity<OdontologoDTO> crear(@RequestBody Odontologo odontologo){
        ResponseEntity response;

        OdontologoDTO odontologoDto = null;
        try {
            odontologoDto = service.crear(odontologo);
            response = ResponseEntity.ok(odontologoDto);
        } catch (ExcepcionesGlobales e) {
            response = ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());

        }


        return response;
    }
    @GetMapping("/{id}")
    public ResponseEntity<OdontologoDTO> buscarPorId(@PathVariable Integer id){
        ResponseEntity response;
        try{
            OdontologoDTO odontologoDTO = service.buscarPorId(id);
            response = ResponseEntity.ok("Se encontro un odontologo correctamente por su id");
        }catch (ExcepcionesGlobales e){
            response = ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
        return response;
    }

    @GetMapping
    public  ResponseEntity<Iterable<OdontologoDTO>> Listar(){
        ResponseEntity response;
        try{
            List<OdontologoDTO> odontologoDTOList = service.listarTodo();
            response = ResponseEntity.ok(odontologoDTOList);
        }catch (ExcepcionesGlobales e){
            response = ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
        return response;
    }

    @PutMapping()
    public ResponseEntity<OdontologoDTO> modificarOdonto(@RequestBody Odontologo odontologo){
        ResponseEntity response;
        try{
            OdontologoDTO OdontologoDto = service.actualizar(odontologo);
            response = ResponseEntity.ok(OdontologoDto);
        }catch (ExcepcionesGlobales e){
            response = ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
        return response;

    }

    @DeleteMapping("/{id}")
    public ResponseEntity<OdontologoDTO> eliminarOdonto(@PathVariable Integer id) {
        ResponseEntity response;
        try {
            service.borrarPorId(id);
            response = ResponseEntity.ok("Se borro con exito al odontologo");
        } catch (ExcepcionesGlobales e) {
            response = ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
        return response;
    }
}
