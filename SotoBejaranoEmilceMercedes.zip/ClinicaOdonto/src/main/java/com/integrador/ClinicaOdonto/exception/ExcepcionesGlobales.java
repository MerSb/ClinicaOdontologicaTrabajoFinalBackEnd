package com.integrador.ClinicaOdonto.exception;

public class ExcepcionesGlobales extends Exception{

    public ExcepcionesGlobales(String mensaje){
        super(mensaje);
    }

}
