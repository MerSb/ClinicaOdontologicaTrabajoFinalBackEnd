package com.integrador.ClinicaOdonto.service;

import com.integrador.ClinicaOdonto.exception.ExcepcionesGlobales;

import java.util.List;

public interface IService <Entity,DTO>{
    DTO crear(Entity entity) throws ExcepcionesGlobales;

    DTO actualizar(Entity entity) throws ExcepcionesGlobales;

    void borrarPorId(Integer id) throws ExcepcionesGlobales;

    List<DTO> listarTodo() throws ExcepcionesGlobales;

    DTO buscarPorId(Integer id) throws ExcepcionesGlobales;

}
