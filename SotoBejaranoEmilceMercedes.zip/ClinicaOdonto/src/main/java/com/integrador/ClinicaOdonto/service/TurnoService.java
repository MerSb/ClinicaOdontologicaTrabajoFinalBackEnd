package com.integrador.ClinicaOdonto.service;

import com.integrador.ClinicaOdonto.DTO.OdontologoDTO;
import com.integrador.ClinicaOdonto.DTO.PacienteDTO;
import com.integrador.ClinicaOdonto.DTO.TurnoDTO;
import com.integrador.ClinicaOdonto.entity.Turno;
import com.integrador.ClinicaOdonto.exception.ExcepcionesGlobales;
import com.integrador.ClinicaOdonto.repository.TurnoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
@Service
public class TurnoService implements IService<Turno, TurnoDTO> {
    @Autowired
    private TurnoRepository repository;

    @Autowired
    private PacienteService pacienteService;
     @Autowired
     private OdontologoService odontologoService;
    //llamar a los servicios//
    @Override
    public TurnoDTO crear(Turno turno) throws ExcepcionesGlobales {
        if(turno.getPaciente() == null || turno.getOdontologo() == null ){
            throw new ExcepcionesGlobales("Error paciente u odontologo no encontrado");
        }

        PacienteDTO pacienteDTO = pacienteService.buscarPorId(turno.getPaciente().getId());
        OdontologoDTO odontologoDTO = odontologoService.buscarPorId(turno.getOdontologo().getId());
        repository.save(turno);

        TurnoDTO turnoDto = new TurnoDTO();
        turnoDto.setId(turno.getId());
        turnoDto.setPacienteDTO(pacienteDTO);
        turnoDto.setOdontologoDTO(odontologoDTO);
        turnoDto.setFecha(turno.getFecha());
        turnoDto.setHora(turno.getHora());
        return turnoDto;
    }

    @Override
    public TurnoDTO actualizar(Turno turno) throws ExcepcionesGlobales {
        if(turno.getPaciente() == null || turno.getOdontologo() == null ){
            throw new ExcepcionesGlobales("Error paciente u odontologo no encontrado");
        }

        Turno turnoEncontrado = repository.findById(turno.getId()).orElse(null);
        if(turnoEncontrado == null){
            throw new ExcepcionesGlobales("no encontrado");
        }
        PacienteDTO pacienteDTO = pacienteService.buscarPorId(turno.getPaciente().getId());
        OdontologoDTO odontologoDTO = odontologoService.buscarPorId(turno.getOdontologo().getId());
        repository.save(turno);

        TurnoDTO turnoDto = new TurnoDTO();
        turnoDto.setId(turno.getId());
        turnoDto.setPacienteDTO(pacienteDTO);
        turnoDto.setOdontologoDTO(odontologoDTO);
        turnoDto.setFecha(turno.getFecha());
        turnoDto.setHora(turno.getHora());
        return turnoDto;
    }

    @Override
    public void borrarPorId(Integer id) throws ExcepcionesGlobales {
        Turno turnoEncontrado = repository.findById(id).orElse(null);
        if(turnoEncontrado == null){
            throw new ExcepcionesGlobales("No se encontro el id que quieres eliminar");
        }
        repository.delete(turnoEncontrado);


    }

    @Override
    public List<TurnoDTO> listarTodo() throws ExcepcionesGlobales {
        List<TurnoDTO> turnoDtoList = new ArrayList<>();
        if(repository.findAll().isEmpty()){
            throw new ExcepcionesGlobales("No se encuentra nada para listar");
        }
        for (Turno t: repository.findAll()){
            PacienteDTO pacienteDTO = pacienteService.buscarPorId(t.getPaciente().getId());
            OdontologoDTO odontologoDTO = odontologoService.buscarPorId(t.getOdontologo().getId());

            TurnoDTO turnoDto = new TurnoDTO();
            turnoDto.setId(t.getId());
            turnoDto.setPacienteDTO(pacienteDTO);
            turnoDto.setOdontologoDTO(odontologoDTO);
            turnoDto.setFecha(t.getFecha());
            turnoDto.setHora(t.getHora());
        }
        return null;
    }

    @Override
    public TurnoDTO buscarPorId(Integer id) throws ExcepcionesGlobales {
        Turno turnoEncontrado = repository.findById(id).orElse(null);

        if (turnoEncontrado == null){
            throw new ExcepcionesGlobales("No Existe");
        }

        PacienteDTO pacienteDto = pacienteService.buscarPorId(turnoEncontrado.getPaciente().getId());
        OdontologoDTO odontologoDto = odontologoService.buscarPorId(turnoEncontrado.getOdontologo().getId());

        TurnoDTO turnoDto = new TurnoDTO();
        turnoDto.setId(turnoEncontrado.getId());
        turnoDto.setPacienteDTO(pacienteDto);
        turnoDto.setOdontologoDTO(odontologoDto);
        turnoDto.setFecha(turnoEncontrado.getFecha());
        turnoDto.setHora(turnoEncontrado.getHora());
        return turnoDto;


    }
}
