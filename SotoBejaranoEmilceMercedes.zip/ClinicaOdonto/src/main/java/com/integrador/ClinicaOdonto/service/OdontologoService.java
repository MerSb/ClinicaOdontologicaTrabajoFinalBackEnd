package com.integrador.ClinicaOdonto.service;

import com.integrador.ClinicaOdonto.DTO.OdontologoDTO;
import com.integrador.ClinicaOdonto.entity.Odontologo;
import com.integrador.ClinicaOdonto.exception.ExcepcionesGlobales;
import com.integrador.ClinicaOdonto.repository.OdontologoRepository;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.swing.text.html.parser.Entity;
import java.util.ArrayList;
import java.util.List;
@Service
public class OdontologoService implements IService<Odontologo, OdontologoDTO> {
    @Autowired
    private OdontologoRepository repository;

    Logger LOGGER = Logger.getLogger(OdontologoService.class);
    @Override
    public OdontologoDTO crear(Odontologo odontologo) throws ExcepcionesGlobales {

        if(odontologo.getNombre().equals(" ") || odontologo.getApellido().equals(" ")){
            throw new ExcepcionesGlobales("Error el nombre o apellido es nulo");
        }

        repository.save(odontologo);
        ///Se puede usar un mapper averiguar///
        OdontologoDTO odontologoDTO = new OdontologoDTO();

        odontologoDTO.setId(odontologo.getId());
        odontologoDTO.setNombre(odontologo.getNombre());
        odontologoDTO.setApellido(odontologo.getApellido());

        LOGGER.info("Se creo un nuevo odontologo");
        return odontologoDTO;
    }

    @Override
    public OdontologoDTO actualizar(Odontologo odontologo) throws ExcepcionesGlobales {
        Odontologo odontoValidar = repository.findById(odontologo.getId()).orElse(null);
        OdontologoDTO odontologoDTO = new OdontologoDTO();
        if(odontoValidar == null){
            throw new ExcepcionesGlobales("No existe el odontologo");
        }
        repository.save(odontologo);

        odontologoDTO.setId(odontologo.getId());
        odontologoDTO.setNombre(odontologo.getNombre());
        odontologoDTO.setApellido(odontologo.getApellido());

        LOGGER.info("Se actualizo un nuevo odontologo");
        return odontologoDTO;
    }

    @Override
    public void borrarPorId(Integer id) throws ExcepcionesGlobales {
        Odontologo odontoBuscado = repository.findById(id).orElse(null);
        if (odontoBuscado == null){
            throw new ExcepcionesGlobales("No se encuentra el odontologo buscado por su id para eliminar");
        }

        repository.delete(odontoBuscado);

    }

    @Override
    public List<OdontologoDTO> listarTodo() throws ExcepcionesGlobales {
        List<OdontologoDTO> odtDtoList = new ArrayList<>();

        if(repository.findAll().isEmpty()){
            throw new ExcepcionesGlobales("No se encuentra nada para listar");
        }


        for (Odontologo o: repository.findAll()) {
            OdontologoDTO odontologoDto = new OdontologoDTO();

            odontologoDto.setId(o.getId());
            odontologoDto.setNombre(o.getNombre());
            odontologoDto.setApellido(o.getApellido());

            odtDtoList.add(odontologoDto);
        }


        return odtDtoList;
    }

    @Override
    public OdontologoDTO buscarPorId(Integer id) throws ExcepcionesGlobales {
        OdontologoDTO odontologoDto = new OdontologoDTO();
        Odontologo odontologoBuscado = repository.findById(id).orElse(null);

        if (odontologoBuscado == null){
            throw new ExcepcionesGlobales("error no existe");
        }

        odontologoDto.setId(odontologoBuscado.getId());
        odontologoDto.setNombre(odontologoBuscado.getNombre());
        odontologoDto.setApellido(odontologoBuscado.getApellido());

        LOGGER.info("Se encontro un nuevo odontologo");
        return odontologoDto;
    }
}
