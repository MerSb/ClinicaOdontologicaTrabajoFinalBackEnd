package com.integrador.ClinicaOdonto.service;

import com.integrador.ClinicaOdonto.DTO.OdontologoDTO;
import com.integrador.ClinicaOdonto.DTO.PacienteDTO;
import com.integrador.ClinicaOdonto.entity.Odontologo;
import com.integrador.ClinicaOdonto.entity.Paciente;
import com.integrador.ClinicaOdonto.exception.ExcepcionesGlobales;
import com.integrador.ClinicaOdonto.repository.OdontologoRepository;
import com.integrador.ClinicaOdonto.repository.PacienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
@Service
public class PacienteService implements IService<Paciente, PacienteDTO> {
    @Autowired
    private PacienteRepository repository;
    @Override
    public PacienteDTO crear(Paciente paciente) throws ExcepcionesGlobales {
        if(paciente.getNombre().equals(" ") || paciente.getApellido().equals(" ")){
            throw new ExcepcionesGlobales("Error el nombre o apellido es nulo");
        }
        repository.save(paciente);
        ///Sepuede usar un mapper averiguar///
        PacienteDTO pacienteDTO = new PacienteDTO();

        pacienteDTO.setId(paciente.getId());
        pacienteDTO.setNombre(paciente.getNombre());
        pacienteDTO.setApellido(paciente.getApellido());
        pacienteDTO.setEmail(paciente.getEmail());

        return pacienteDTO;
    }

    @Override
    public PacienteDTO actualizar(Paciente paciente) throws ExcepcionesGlobales {
        Paciente pacienteValidar = repository.findById(paciente.getId()).orElse(null);
        PacienteDTO pacienteDTO = new PacienteDTO();
        if(pacienteValidar == null){
            throw new ExcepcionesGlobales("No existe el odontologo");
        }
        repository.save(paciente);

        pacienteDTO.setId(paciente.getId());
        pacienteDTO.setNombre(paciente.getNombre());
        pacienteDTO.setApellido(paciente.getApellido());

        return pacienteDTO;
    }

    @Override
    public void borrarPorId(Integer id) throws ExcepcionesGlobales {
        Paciente pacienteBuscado = repository.findById(id).orElse(null);
        if (pacienteBuscado == null){
            throw new ExcepcionesGlobales("No se encuentra el odontologo buscado por su id");
        }

        repository.delete(pacienteBuscado);

    }

    @Override
    public List<PacienteDTO> listarTodo() throws ExcepcionesGlobales {
        List<PacienteDTO> odtDtoList = new ArrayList<>();

        if(repository.findAll().isEmpty()){
            throw new ExcepcionesGlobales("No se encuentra nada para listar");
        }

        for (Paciente o: repository.findAll()) {
            PacienteDTO pacienteDto = new PacienteDTO();

            pacienteDto.setId(o.getId());
            pacienteDto.setNombre(o.getNombre());
            pacienteDto.setApellido(o.getApellido());
            pacienteDto.setEmail(o.getEmail());


            odtDtoList.add(pacienteDto);
        }


        return odtDtoList;
    }

    @Override
    public PacienteDTO buscarPorId(Integer id) throws ExcepcionesGlobales {
        PacienteDTO pacienteDto = new PacienteDTO();
        Paciente pacienteBuscado = repository.findById(id).orElse(null);

        if (pacienteBuscado == null){
            throw new ExcepcionesGlobales("error no existe");
        }

        pacienteDto.setId(pacienteBuscado.getId());
        pacienteDto.setNombre(pacienteBuscado.getNombre());
        pacienteDto.setApellido(pacienteBuscado.getApellido());
        pacienteDto.setEmail(pacienteBuscado.getEmail());


        return pacienteDto;
    }
}
