package com.integrador.ClinicaOdonto.controller;

import com.integrador.ClinicaOdonto.DTO.PacienteDTO;
import com.integrador.ClinicaOdonto.DTO.TurnoDTO;
import com.integrador.ClinicaOdonto.entity.Turno;
import com.integrador.ClinicaOdonto.exception.ExcepcionesGlobales;
import com.integrador.ClinicaOdonto.service.TurnoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/turnos")
public class TurnoController {
    @Autowired
    private TurnoService service;

    @PostMapping
    public ResponseEntity<TurnoDTO> crear(@RequestBody Turno turno){
        ResponseEntity response;

        TurnoDTO turnoDTO = null;
        try {
            turnoDTO = service.crear(turno);
            response = ResponseEntity.ok(turnoDTO);
        } catch (ExcepcionesGlobales e) {
            response = ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());

        }


        return response;
    }
    @GetMapping("/{id}")
    public ResponseEntity<TurnoDTO> buscarPorId(@PathVariable Integer id){
        ResponseEntity response;
        try{
            TurnoDTO turnoDTO = service.buscarPorId(id);
            response = ResponseEntity.ok("Se encontro un turno correctamente por su id");
        }catch (ExcepcionesGlobales e){
            response = ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
        return response;
    }
    @GetMapping
    public  ResponseEntity<Iterable <TurnoDTO>> Listar(){
        ResponseEntity response;
        try{
            List<TurnoDTO> turnoDTOList = service.listarTodo();
            response = ResponseEntity.ok(turnoDTOList);
        }catch (ExcepcionesGlobales e){
            response = ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
        return response;
    }
    @PutMapping()
    public ResponseEntity<PacienteDTO> modificarTurno(@RequestBody Turno turno){
        ResponseEntity response;
        try{
            TurnoDTO turnoDTO = service.actualizar(turno);
            response = ResponseEntity.ok(turnoDTO);
        }catch (ExcepcionesGlobales e){
            response = ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
        return response;

    }
    @DeleteMapping("/{id}")
    public ResponseEntity<PacienteDTO> eliminarTurno(@PathVariable Integer id) {
        ResponseEntity response;
        try {
            service.borrarPorId(id);
            response = ResponseEntity.ok("Se borro con exito al turno");
        } catch (ExcepcionesGlobales e) {
            response = ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
        return response;
    }



}
