package com.integrador.ClinicaOdonto.service;

import com.integrador.ClinicaOdonto.entity.Odontologo;
import com.integrador.ClinicaOdonto.exception.ExcepcionesGlobales;
import com.integrador.ClinicaOdonto.repository.OdontologoRepository;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class OdontologoServiceTest {

    @Mock
    OdontologoRepository repository;
    @InjectMocks
    OdontologoService service;


    void create() throws ExcepcionesGlobales {
//        //Arrange
        Odontologo odontologo = new Odontologo(1,"pepe","mujica",12545L);

        when(repository.save(any())).thenReturn(odontologo);

//        //Act
        OdontologoDTO odontologoDevuelto = service.crear(odontologo);

        OdontologoDTO odontologoEsperado = new OdontologoDTO(1,"Hugo","Steckler");
//        //Assert
        Assertions.assertEquals(odontologoEsperado,odontologoDevuelto);
    }

    @Test
    void create_test_exception(){
        Odontologo odontologo = new Odontologo(1,"Hugo","Steckler",12345L);
//        doNothing().when(repository).save(any());
        when(repository.save(any())).thenReturn(odontologo);
        Assertions.assertDoesNotThrow(() -> {
            service.crear(odontologo);
        });
    }

    @Test
    void create_test_entrando_exception(){


        Odontologo odontologo = new Odontologo(1,"Hu2go","Steckler",12345L);
//        doNothing().when(repository).save(any());
        when(repository.save(any())).thenReturn(odontologo);
        Assertions.assertThrows(GlobalException.class, ()-> {
            service.crear(odontologo);
        });
    }

    @Test
    void delete_test_sin_exeption() throws GlobalException {
        Odontologo odontologo = new Odontologo(1,"Hugo","Steckler",12345L);

        when(repository.findById(odontologo.getId())).thenReturn(Optional.of(odontologo));

        //Act
        service.borrarPorID(odontologo.getId());

        //Assert
        Assertions.assertDoesNotThrow(()-> {
            service.borrarPorID(odontologo.getId());
        });
    }

    @Test
    void delete_test_exception(){
        Odontologo odontologo = new Odontologo(1,"Hugo","Steckler",12345L);

        when(repository.save(any())).thenReturn(odontologo);


        Assertions.assertThrows(GlobalException.class,()-> service.borrarPorID(odontologo.getId()));
    }

    @Test
    void update() throws GlobalException {
        Odontologo odontologo = new Odontologo(1, "Hugo", "Steckler", 12345L);
        Odontologo odontologoActualizado = new Odontologo(1, "Jose", "Steckler", 12345L);

        when(repository.findById(odontologo.getId())).thenReturn(Optional.of(odontologo));
        when(repository.save(odontologoActualizado)).thenReturn(odontologoActualizado);

        Assertions.assertDoesNotThrow(() -> {
            service.actualizar(odontologoActualizado);
        });

    }

    @Test
    void update_test_con_exception(){
        Odontologo odontologo = new Odontologo(1, "Hugo", "Steckler", 12345L);
        Odontologo odontologoActualizado = new Odontologo(1, "Jo2e", "Steckler", 12345L);

        when(repository.findById(odontologo.getId())).thenReturn(Optional.of(odontologo));
        when(repository.save(odontologoActualizado)).thenReturn(odontologoActualizado);

        Assertions.assertThrows(GlobalException.class, ()-> {
            service.actualizar(odontologoActualizado);
        });
    }
    @Test
    void update_test_con_exception_no_existe(){
        Odontologo odontologo = new Odontologo(1, "Hugo", "Steckler", 12345L);
        Odontologo odontologoActualizado = new Odontologo(2, "Jose", "Steckler", 12345L);

        when(repository.findById(odontologo.getId())).thenReturn(Optional.of(odontologo));
        when(repository.save(odontologoActualizado)).thenReturn(odontologoActualizado);

        Assertions.assertThrows(GlobalException.class, ()-> {
            service.actualizar(odontologoActualizado);
        });
    }

    @Test
    void getall_test_lista_vacia() {
        when(repository.findAll()).thenReturn(new ArrayList<Odontologo>());

        assertThrows(GlobalException.class, () -> {
            service.listarTodo();
        }, "La lista está vacía");
    }

    @Test
    void getall_test_lista() throws GlobalException {
        Odontologo odontologo = new Odontologo(1,"Hugo","Steckler",12345L);
        Odontologo odontologo1 = new Odontologo(2,"Jose","Steckler",12345L);

        List<Odontologo> odontologoList = new ArrayList<>();
        odontologoList.add(odontologo);
        odontologoList.add(odontologo1);

        List<OdontologoDTO> odontologoEsperado = Arrays.asList(new OdontologoDTO(1,"Hugo","Steckler"),
                new OdontologoDTO(2,"Jose","Steckler"));
        doReturn(odontologoList).when(repository).findAll();

        List<OdontologoDTO> odontologoDevueltos = service.listarTodo();
        Assertions.assertIterableEquals(odontologoDevueltos,odontologoEsperado);
    }

    @Test
    void getById() throws GlobalException {
        Odontologo odontologo = new Odontologo(1,"Hugo","Steckler",12345L);

        when(repository.findById(odontologo.getId())).thenReturn(Optional.of(odontologo));
        OdontologoDTO odontologoDTOEsperado = new OdontologoDTO(1,"Hugo","Steckler");
        OdontologoDTO odontologoDTODevuelto = service.buscarPorID(1);
        Assertions.assertEquals(odontologoDTODevuelto,odontologoDTOEsperado);
    }

    @Test
    void getById_exception_null() throws GlobalException {
        Odontologo odontologo = new Odontologo(null,"Hugo","Steckler",12345L);

        when(repository.findById(odontologo.getId())).thenReturn(Optional.of(odontologo));

        Assertions.assertThrows(GlobalException.class,()-> {
            service.buscarPorID(odontologo.getId());
        });
    }

    @Test
    void getById_exception_null_odontologo() throws GlobalException {
        Integer id = null;

        Assertions.assertThrows(GlobalException.class,()-> {
            service.buscarPorID(id);
        });
    }
}